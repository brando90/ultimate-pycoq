# sample coq source files

This directory contains modified copies of proof scripts from the  "Software Foundations"  https://softwarefoundations.cis.upenn.edu/lf-current/index.html under the terms specified in LICENSE.


