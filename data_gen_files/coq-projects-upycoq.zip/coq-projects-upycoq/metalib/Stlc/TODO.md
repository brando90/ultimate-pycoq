DONE
* add more explanation to beginning of tutorial, especially about the role of
  Ott and LNgen. Lose talk.mng.

* merge metalib 8.6 into master

* recover STLCsol as simple, standalone tutorial
* Better definition of get in metalib
* add lngen autorewrites to default_simp

* improve  behavior of fsetdec

SOONER
* make coqdoc output readable (sf-like)

* merge metalib dsss into master

DONT DO
* Universe polymorphism in metalib [no! nat is a Set]
* Universe polymorphism in metalib [nat is in Set!]
* Break out notations in metalib  add notation scopes [already there]



LATER

* LNgen generate close_freshen

* Company-coq and completion from other modules

* theory of get

* can replace apply_heap/apply_stack/fv_stack with fold?

* patch Ott for metalib namespace (more generally, allow embeds at beginning
  of file.)

* merge branches for LNgen into master (make old releases?)

* edit Ott to produce good nominal output

* patch Ott for fset based fv function

* Type classes ??? for LNgen

* produce nominal lngen -- i.e. autogenerate swap & auto prove equivariance
