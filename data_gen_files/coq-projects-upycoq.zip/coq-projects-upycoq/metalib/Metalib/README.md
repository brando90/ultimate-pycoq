COMPILATION, INSTALLATION, AND DOCUMENTATION:

  This library requires Coq 8.6, available via [opam](https://opam.ocaml.org/)
  or from the Coq website [https://coq.inria.fr/download].

  To compile the library:

      `make`          generate Coq makefile, compile Coq files
      `make doc`      generate Coq documentation
      `make install`  install library on your system
