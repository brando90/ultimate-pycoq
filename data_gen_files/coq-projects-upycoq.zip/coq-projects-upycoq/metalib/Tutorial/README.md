This is a simple tutorial demonstrating the Metatheory library. It was
developed for POPL 2008 and also used at OPLSS.

The exercises are in STLC.v and the solutions in STLCsol.v.
