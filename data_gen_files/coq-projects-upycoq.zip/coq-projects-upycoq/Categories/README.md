# README #

This is an implementation of category theory in Coq.

## Coq version and compilation ##

* This development uses features new to Coq8.6
* It has been tested on Debian with Coq 8.6
* To compile simply type
    * ``` ./configure ``` to produce the Makefile [1] and then
    * ``` make ``` to compile

[1] you will need to have coq_makefile to be on the path
