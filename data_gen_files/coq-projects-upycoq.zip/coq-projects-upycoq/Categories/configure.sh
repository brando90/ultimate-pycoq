#!/bin/sh

coq_makefile -f _CoqProject -o Makefile
