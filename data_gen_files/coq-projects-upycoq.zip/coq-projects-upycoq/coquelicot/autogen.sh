#!/bin/sh
touch ChangeLog
autoreconf -i -s
