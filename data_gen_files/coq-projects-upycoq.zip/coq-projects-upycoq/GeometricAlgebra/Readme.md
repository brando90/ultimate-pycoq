[![Build Status](https://travis-ci.org/thery/GeometricAlgebra.svg?branch=master)](https://travis-ci.org/thery/GeometricAlgebra)

This is an update of the original project [GeometricAlgebra](http://www-sop.inria.fr/marelle/GeometricAlgebra/).

The project should now be compatible with Coq 8.8.2.

Simply run `make` to compile the relevant files.

This is the content of the old Readme:

>This archive contains all the material of the formalisation of our Grassman
>Cayley and Clifford formalisation. It has been developped with Coq 8.3
>To compile it, a simple make should be enough
>
>Laurent.Fuchs@sic.univ-poitiers.fr
>Laurent.Thery@inria.fr
